package coder.prettygirls.data.source.local;

import coder.prettygirls.data.source.GirlsDataSource;

/**
 * Created by oracleen on 2016/6/29.
 */
public class LocalGirlsDataSource implements GirlsDataSource {

    @Override
    public void getGirls(int page, int size, LoadGirlsCallback callback) {

    }

    @Override
    public void getGirl(LoadGirlsCallback callback) {

    }
}
